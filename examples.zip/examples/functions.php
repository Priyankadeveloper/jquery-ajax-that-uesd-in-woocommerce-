<?php
/**
 * Storefront engine room
 *
 * @package storefront
 */

/**
 * Assign the Storefront version to a var
 */
$theme              = wp_get_theme( 'storefront' );
$storefront_version = $theme['Version'];

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 980; /* pixels */
}

$storefront = (object) array(
	'version' => $storefront_version,

	/**
	 * Initialize all the things.
	 */
	'main'       => require 'inc/class-storefront.php',
	'customizer' => require 'inc/customizer/class-storefront-customizer.php',
);

require 'inc/storefront-functions.php';
require 'inc/storefront-template-hooks.php';
require 'inc/storefront-template-functions.php';

if ( class_exists( 'Jetpack' ) ) {
	$storefront->jetpack = require 'inc/jetpack/class-storefront-jetpack.php';
}

if ( storefront_is_woocommerce_activated() ) {
	$storefront->woocommerce = require 'inc/woocommerce/class-storefront-woocommerce.php';

	require 'inc/woocommerce/storefront-woocommerce-template-hooks.php';
	require 'inc/woocommerce/storefront-woocommerce-template-functions.php';
}

if ( is_admin() ) {
	$storefront->admin = require 'inc/admin/class-storefront-admin.php';

	require 'inc/admin/class-storefront-plugin-install.php';
}

/**
 * NUX
 * Only load if wp version is 4.7.3 or above because of this issue;
 * https://core.trac.wordpress.org/ticket/39610?cversion=1&cnum_hist=2
 */
if ( version_compare( get_bloginfo( 'version' ), '4.7.3', '>=' ) && ( is_admin() || is_customize_preview() ) ) {
	require 'inc/nux/class-storefront-nux-admin.php';
	require 'inc/nux/class-storefront-nux-guided-tour.php';

	if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '3.0.0', '>=' ) ) {
		require 'inc/nux/class-storefront-nux-starter-content.php';
	}
}

function crispshop_scripts() {
    if (is_singular('product')) {
	    wp_enqueue_script( 'crispshop-single', get_template_directory_uri() . '/js/crispshop-single.js', array('jquery'), '1.0.0', true );
	    wp_localize_script( 'crispshop-single', 'crispshop_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}
}
add_action( 'wp_enqueue_scripts', 'crispshop_scripts' );

/**
 * Note: Do not add any custom code here. Please use a custom plugin so that your customizations aren't lost during updates.
 * https://github.com/woocommerce/theme-customisations
 */
/* add new*/

function crispshop_add_cart_single_ajax() {
	$product_id = $_POST['product_id'];
	$variation_id = $_POST['variation_id'];
	$variationa_ida = $_POST['variation_ida'];
	$quantity = $_POST['quantity'];
	$variationa_txt=$_POST['variationa_txt'];
$obj = new WC_Product($product_id); 
 $price = $obj->get_price()+$variationa_ida;
  $cart_item_data=array('customdata'=>$price,'variationa_txt'=>$variationa_txt);


	if ($variation_id) {
		
		WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation, $cart_item_data );
	} else {
		WC()->cart->add_to_cart( $product_id, $quantity);
	}

	$items = WC()->cart->get_cart();
	$item_count = count($items); ?>

	<span class="item-count"><?php echo $item_count; ?></span>

	<h4>Shopping Bag</h4>

	<?php foreach($items as $item => $values) { 
		$_product = $values['data']->post; ?>
		
		<div class="dropdown-cart-wrap">
			<div class="dropdown-cart-left">
				<?php $variation = $values['variation_id'];
                if ($variation) {
                    echo get_the_post_thumbnail( $values['variation_id'], 'thumbnail' ); 
                } else {
                    echo get_the_post_thumbnail( $values['product_id'], 'thumbnail' ); 
                } ?>
			</div>

			<div class="dropdown-cart-right">
				<h5><?php echo $_product->post_title; echo $variationa_txt; ?></h5>
				<p><strong>Quantity:</strong> <?php echo $values['quantity']; ?></p>
				<?php global $woocommerce;
				$currency = get_woocommerce_currency_symbol();
				$price = get_post_meta( $values['product_id'], '_regular_price', true);
				$sale = get_post_meta( $values['product_id'], '_sale_price', true);

				?>
				 
				<?php if($sale) { ?>
					<p class="price"><strong>Price:</strong> <del><?php echo $currency; echo $price; ?></del> <?php echo $currency; echo $sale; ?></p>
				<?php } elseif($price) { ?>
					<p class="price"><strong>Price:</strong> <?php echo $currency; echo $price; ?></p>    
				<?php } ?>
			</div>

			<div class="clear"></div>
		</div>
	<?php } ?>

	<div class="dropdown-cart-wrap dropdown-cart-subtotal">
		<div class="dropdown-cart-left">
			<h6>Subtotal</h6>
		</div>

		<div class="dropdown-cart-right">
			<h6><?php echo WC()->cart->get_cart_total(); ?></h6>
		</div>

		<div class="clear"></div>
	</div>

	<?php $cart_url = $woocommerce->cart->get_cart_url();
	$checkout_url = $woocommerce->cart->get_checkout_url(); ?>

	<div class="dropdown-cart-wrap dropdown-cart-links">
		<div class="dropdown-cart-left dropdown-cart-link">
			<a href="<?php echo $cart_url; ?>">View Cart</a>
		</div>

		<div class="dropdown-cart-right dropdown-checkout-link">
			<a href="<?php echo $checkout_url; ?>">Checkout</a>
		</div>

		<div class="clear"></div>
	</div>

	<?php die();
}

add_action('wp_ajax_crispshop_add_cart_single', 'crispshop_add_cart_single_ajax');
add_action('wp_ajax_nopriv_crispshop_add_cart_single', 'crispshop_add_cart_single_ajax');

function action_woocommerce_before_add_to_cart_buttona(  ) { ?>

	<select onChange="getData();" id="asection">
		  <option>Select The value</option>

  <option value="10">A</option>
    <option value="20">B</option>

 </select><?php
    // make action magic happen here... 
}; 
         add_action( 'woocommerce_before_add_to_cart_button', 'action_woocommerce_before_add_to_cart_buttona', 10, 0 ); 

         function action_woocommerce_before_add_to_cart_buttonb(  ) { ?>

	<select id="bsection">
		    <option>Select The value</option>

  <option value="20">b</option>
 </select><?php
    // make action magic happen here... 
}; 
         add_action( 'woocommerce_before_add_to_cart_button', 'action_woocommerce_before_add_to_cart_buttonb', 10, 0 ); 

add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );

function add_custom_price( $cart_object ) {
   $custom_price = 10; // This will be your custom price  
   foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
       $cart_item['data']->set_price($cart_item['customdata']);  
   }
}

function render_meta_on_cart_and_checkout( $cart_data, $cart_item = null ) {
    $custom_items = array();
    /* Woo 2.4.2 updates */
    if( !empty( $cart_data ) ) {
        $custom_items = $cart_data;
    }
    if( isset( $cart_item['variationa_txt'] ) ) {
        $custom_items[] = array( "name" => 'Name of variant', "value" => $cart_item['variationa_txt'] );
    }
    return $custom_items;
}
add_filter( 'woocommerce_get_item_data', 'render_meta_on_cart_and_checkout', 10, 2 );

function tshirt_order_meta_handler( $item_id, $values, $cart_item_key ) {
    if( isset( $values['variationa_txt'] ) ) {
        wc_add_order_item_meta( $item_id, "variation product", $values['variationa_txt'] );
    }
}
add_action( 'woocommerce_add_order_item_meta', 'tshirt_order_meta_handler', 1, 3 );


/* add new*/